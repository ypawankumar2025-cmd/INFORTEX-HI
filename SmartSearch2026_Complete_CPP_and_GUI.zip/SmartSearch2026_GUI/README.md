# SmartSearch 2026 — Google-inspired C++ Search Engine

An intermediate C++17 terminal project demonstrating **all four OOP pillars**, file persistence, STL containers, a word-to-documents inverted index, keyword search, and a simplified **TF-IDF-inspired** result ranking.

**Important:** This is an educational, offline, local-document search engine. It does not connect to Google, crawl the web, or copy Google's ranking formula.

## Features
- Starts with 8 sample documents on the first run
- Add or delete documents (persisted to `data/documents.txt`)
- Search multiple keywords without case sensitivity
- Inverted index for candidate retrieval (word → matching document IDs)
- Scores candidates with log term-frequency, inverse document frequency, title boost, and small recency boost
- Top-10 ranked search results
- Stores and displays last 10 search queries (`data/history.txt`)
- Basic validation and file I/O exception handling

## Requirements
- Any C++17 compiler (g++ 8+, clang++, MSVC with C++17)
- CMake optional, not needed for direct compilation

## Compile and run (Windows / Linux / macOS)
From the project folder:

```bash
g++ -std=c++17 -Wall -Wextra -Iinclude src/main.cpp src/search_engine.cpp -o smartsearch
./smartsearch
```

On Windows PowerShell, compile with the same command and run `./smartsearch.exe`.

Or use CMake:

```bash
cmake -S . -B build
cmake --build build
./build/smartsearch
```

## Example session

```text
Welcome! 8 documents indexed.
========== SMARTSEARCH 2026 ==========
1. Search documents
2. Add document
3. List documents
4. Delete document
5. View recent searches
0. Exit
Enter your choice: 1
Search keywords: cpp interview
Found 4 matching documents.
```

Counts vary as you add or remove documents.

## How data moves through the program

```text
User enters query: "cpp interview"
                |
                v
Tokenize -> lowercase -> ["cpp", "interview"]
                |
                v
Inverted index returns candidate document IDs for each term
                |
                v
RankingStrategy::score() dispatched to TfidfRanker::score()
                |
                v
TF-IDF-like weighted score + title boost + freshness boost
                |
                v
Sort by highest score -> display top 10
```

## OOP concepts (with file references)

| Principle | In this project |
|---|---|
| **Encapsulation** | SearchEngine keeps `documents`, `index`, and `repository` private; exposes public search/add/delete methods. |
| **Abstraction** | `RankingStrategy` defines a pure virtual interface without dictating the scoring implementation. |
| **Inheritance** | `TfidfRanker` inherits from `RankingStrategy`. |
| **Polymorphism** | `SearchEngine` stores a `unique_ptr<RankingStrategy>`, and `ranker->score()` invokes the concrete class at runtime. |
| **Constructors** | Repository, History, and Engine set up dependencies. |
| **Composition** | SearchEngine owns DocumentRepository and a ranking strategy. |

## Algorithm in plain English

1. During initialization, read saved documents. If first launch, create 8 samples.
2. Make an **inverted index**: for each lowercase word, store the frequency in each document.
3. When a query arrives, split it into words and remove duplicates.
4. Take the union of document IDs in the postings lists (OR search).
5. For each matching document, compute score:
   - `TF = 1 + ln(frequency)`
   - `IDF = ln(1 + (N - df + 0.5) / (df + 0.5))`
   - add `2 × occurrences_in_title` for each query word
   - multiply by `1 + 0.02 × clamp(year - 2020, 0, 6)`
6. Sort descending by score and display at most 10 results.

**This is our own educational ranking formula, not Google's.** Results use OR keyword matching; semantic meaning is not implemented.

## Run a smoke test

```bash
python tests/smoke_test.py
```

This runs a fresh build in a temporary directory and checks search, save, history, deletion and persistence.

## Files

```text
SmartSearch2026/
  CMakeLists.txt
  README.md
  include/search_engine.hpp   # Class declarations and interface
  src/search_engine.cpp       # Tokenizer, index, ranking, persistence
  src/main.cpp                # Menu, user interaction, validation
  tests/smoke_test.py         # Automated end-to-end check
  data/                       # Auto-created at runtime
```

## Interview / viva questions to practice
1. Why is an inverted index faster than scanning every document for every query?
2. Difference between a pure virtual function and an overridden function?
3. Why choose `unique_ptr` for the ranking strategy?
4. What is the difference between term frequency (TF) and document frequency (DF)?
5. Why use `unordered_map` instead of `map` for the inverted index?
6. What happens to the index after you add/delete documents?
7. How would you add a new ranking class without changing SearchEngine?
8. Which search queries would OR search give surprising results for?

## Limitations and possible next features
- Searches **English/ASCII keywords** only in this version (not full Telugu/Unicode tokenization)
- No actual URL crawling, live internet results, embeddings, spellcheck or ML models
- `rebuildIndex()` reindexes all documents after every edit; use incremental postings updates later
- For a production project, use transactional database storage and unit tests
- Extensions: BM25 scoring, stop-word filtering, spelling suggestions, search autocomplete, pagination, and REST API

## Google concept references
- https://developers.google.com/search/docs/fundamentals/how-search-works
- https://www.google.com/intl/en_in/search/howsearchworks/how-search-works/ranking-results/
