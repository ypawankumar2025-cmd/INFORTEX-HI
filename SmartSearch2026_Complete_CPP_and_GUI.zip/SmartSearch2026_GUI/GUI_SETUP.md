# SmartSearch 2026 — Graphical C++ Desktop App

## What is included?
This is the original C++17 search engine **plus** a real native Qt 6 Widgets GUI.
No web browser and no Google API are required. It is an **offline local-document search engine**, not a Google clone.

### GUI pages
1. **Search:** Google-style text box, Search button or Enter, ranked result cards, relevance scores.
2. **Document Library:** View indexed documents, add a document, delete a document with confirmation.
3. **Recent Searches:** Last 10 queries, click a query to search again.

The backend is unchanged: inverted-index candidate retrieval, TF-IDF-inspired relevance scoring, document persistence, and search history remain in C++.

## How to build on Windows (recommended: Qt Creator)

1. Install **Qt Online Installer** from [Qt official site](https://www.qt.io/download-qt-installer-oss). Select Qt open source if appropriate for your use (check licensing).
2. In its components, install **Qt Creator**, a **Qt 6 desktop kit** with **Qt Widgets**, CMake, and the compiler that matches the kit (such as MinGW 64-bit or MSVC). An IDE alone is not the Qt SDK.
3. Extract this ZIP, open `CMakeLists.txt` in **Qt Creator** via **File > Open File or Project**.
4. Select the installed **Desktop Qt 6 kit** when prompted. Qt Creator will configure CMake.
5. In target selection choose **smartsearch_gui**, then click the green **Run** triangle. `smartsearch` is the original terminal target.
6. In the GUI, try the keyword `cpp interview`, then open Document Library to add and delete documents.

> VS Code can be used, but Qt Creator handles compiler, Qt SDK, CMake, and running a GUI more easily for beginners. A normal standalone `g++` command without Qt SDK headers/libraries cannot build this GUI.

## Manual build with configured Qt 6 on PATH

```sh
cmake -S . -B build
cmake --build build --config Release --target smartsearch_gui
```

If CMake cannot find Qt 6, configure from Qt Creator or pass `-DCMAKE_PREFIX_PATH=<path to your Qt 6 kit>` to CMake. On Windows using a multi-configuration generator, look in `build/Release/` for the executable; single-configuration builds often place it in `build/`.

## Files

```
SmartSearch2026_GUI/
  CMakeLists.txt             # builds console and (if Qt installed) desktop app
  GUI_SETUP.md               # this guide
  include/search_engine.hpp # OOP contracts, search algorithm interface
  src/search_engine.cpp     # engine, file save/load, TF-IDF-inspired scoring
  src/main.cpp              # original console UI
  gui/main.cpp              # QApplication + storage folder + startup
  gui/mainwindow.hpp        # SearchWindow GUI class
  gui/mainwindow.cpp        # windows, buttons, layouts, signals/callbacks
  tests/smoke_test.py       # original engine test
```

### Execution flow
```
GUI opens -> QApplication runs -> SearchWindow constructed -> engine.initialize()
          -> buildInterface() draws search/list/history pages
User types query -> clicks Search -> performSearch() -> SearchEngine::search()
          -> tokenize -> inverted index -> TfidfRanker::score() -> sort results
          -> renderResults() creates result cards in the GUI
User clicks Add -> Qt dialog -> SearchEngine::addDocument()
          -> persist documents -> rebuild index -> refresh library
```

### Where do saved documents go?
The graphical version uses the OS's Qt `QStandardPaths::AppDataLocation` directory (not the current terminal working directory). On Windows this is typically under a user's AppData area. Qt chooses the exact application-specific path. The CLI uses `data/` in your current working directory, so the two apps **do not automatically share the same files**.

### Testing note
The existing console engine is covered by the smoke test. The GUI requires an actual Qt 6 Widgets SDK to compile and run; the source cannot be runtime-tested unless Qt is installed. This ZIP contains **source**, not a ready-to-run Windows `.exe`.

## References
Official Qt docs:
- https://doc.qt.io/qt-6/qtwidgets-index.html
- https://doc.qt.io/qt-6/cmake-get-started.html
- https://doc.qt.io/qtcreator/creator-how-to-install.html
