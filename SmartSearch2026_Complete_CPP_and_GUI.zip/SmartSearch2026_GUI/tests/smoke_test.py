"""End-to-end smoke test using only Python's standard library."""
from pathlib import Path
from subprocess import run
from tempfile import TemporaryDirectory

root = Path(__file__).resolve().parents[1]
with TemporaryDirectory() as temp_dir:
    temp = Path(temp_dir)
    binary = temp / "smartsearch"
    build = run(
        ["g++", "-std=c++17", "-Wall", "-Wextra", "-I" + str(root / "include"),
         str(root / "src" / "main.cpp"), str(root / "src" / "search_engine.cpp"),
         "-o", str(binary)],
        capture_output=True, text=True, check=True
    )
    session = "1\ncpp interview\n2\nGraph Interview Guide\nGraphs trees cpp interview\n2026\n1\ngraphs\n4\n9\n5\n0\n"
    first = run([str(binary)], input=session, capture_output=True, text=True,
                cwd=temp, check=True)
    assert "Found 4 matching documents." in first.stdout
    assert "Saved and indexed successfully! ID = 9" in first.stdout
    assert "Found 2 matching documents." in first.stdout
    assert "Document deleted." in first.stdout
    assert "- cpp interview" in first.stdout
    assert (temp / "data" / "documents.txt").exists()
    assert (temp / "data" / "history.txt").exists()

    second = run([str(binary)], input="3\n0\n", capture_output=True,
                 text=True, cwd=temp, check=True)
    assert "8 documents indexed" in second.stdout
    assert "[9]" not in second.stdout

print("PASS: search, ranking candidates, add, delete, history, and persistence")
