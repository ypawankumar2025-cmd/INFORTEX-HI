#include "mainwindow.hpp"

#include <QAbstractItemView>
#include <QDate>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFont>
#include <QFormLayout>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPushButton>
#include <QScrollArea>
#include <QSizePolicy>
#include <QSpinBox>
#include <QStackedWidget>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QWidget>

#include <algorithm>
#include <exception>
#include <filesystem>
#include <memory>
#include <string>
#include <vector>

namespace {
constexpr int kSearchPage = 0;
constexpr int kLibraryPage = 1;
constexpr int kHistoryPage = 2;

QString qs(const std::string& input) {
    return QString::fromUtf8(input.data(), static_cast<qsizetype>(input.size()));
}

QLabel* plainLabel(const QString& text, const QString& styleName = "", QWidget* parent = nullptr) {
    auto* label = new QLabel(text, parent);
    label->setTextFormat(Qt::PlainText);
    label->setWordWrap(true);
    if (!styleName.isEmpty()) label->setObjectName(styleName);
    return label;
}

void clearItems(QVBoxLayout* layout) {
    if (!layout) return;
    while (QLayoutItem* item = layout->takeAt(0)) {
        if (QWidget* widget = item->widget()) widget->deleteLater();
        delete item;
    }
}

QFrame* panel(QWidget* parent = nullptr) {
    auto* frame = new QFrame(parent);
    frame->setObjectName("panel");
    return frame;
}

QWidget* scrolledList(QVBoxLayout*& destination, QWidget* parent = nullptr) {
    auto* scroll = new QScrollArea(parent);
    scroll->setObjectName("resultScroll");
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    auto* container = new QWidget(scroll);
    container->setObjectName("scrollContent");
    destination = new QVBoxLayout(container);
    destination->setContentsMargins(2, 6, 8, 12);
    destination->setSpacing(12);
    scroll->setWidget(container);
    return scroll;
}

QString excerpt(const std::string& text, int maximum = 220) {
    QString result = qs(text).simplified();
    return result.size() > maximum ? result.left(maximum) + QStringLiteral("...") : result;
}

const char* kStyle = R"CSS(
    QMainWindow, QWidget#root { background: #0B1220; color: #EAF1FF; }
    QWidget { color: #EAF1FF; font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; }
    QWidget#sidebar { background: #101D31; border-right: 1px solid #243752; }
    QLabel#brand { color: #80B8FF; font-size: 21px; font-weight: 800; }
    QLabel#headline { font-size: 28px; font-weight: 750; color: #F0F6FF; }
    QLabel#caption { font-size: 13px; color: #9AB0CD; }
    QLabel#section { font-size: 16px; font-weight: 700; }
    QLabel#cardTitle { color: #DAE9FF; font-size: 15px; font-weight: 700; }
    QLabel#meta { color: #8FACC9; font-size: 12px; }
    QLabel#count { color: #72C5B1; font-size: 12px; }
    QLabel#empty { color: #93A9C5; font-size: 14px; }
    QLabel#historyText { color: #BED2EE; font-size: 13px; }
    QFrame#panel { background: #13233B; border: 1px solid #2B4362; border-radius: 13px; }
    QLineEdit, QTextEdit, QSpinBox { background: #14243A; color: #F1F6FF; border: 1px solid #36506F;
        border-radius: 10px; padding: 10px; selection-background-color: #2563EB; }
    QLineEdit:focus, QTextEdit:focus, QSpinBox:focus { border: 1px solid #65A5FF; }
    QPushButton { border-radius: 9px; padding: 10px 16px; font-weight: 600;
        background: #203654; color: #DFECFF; border: 1px solid #345071; }
    QPushButton:hover { background: #2A456A; }
    QPushButton#primary { background: #3477E7; color: white; border: 1px solid #438AFF; }
    QPushButton#primary:hover { background: #4E91F8; }
    QPushButton#danger { background: #442B3B; border-color: #754052; color: #FFC5C5; }
    QPushButton#nav { text-align: left; padding: 13px 16px; background: transparent; border: none; color: #A9BDD8; }
    QPushButton#nav:hover { background: #1E3352; }
    QPushButton#navActive { text-align: left; padding: 13px 16px; background: #214477;
        border: 1px solid #3A6193; color: #EFF6FF; }
    QScrollArea, QWidget#scrollContent { background: transparent; border: none; }
    QScrollBar:vertical { background: #101C30; width: 10px; }
    QScrollBar::handle:vertical { background: #365272; border-radius: 5px; min-height: 25px; }
)CSS";
} // namespace

SearchWindow::SearchWindow(const std::string& dataDirectory, QWidget* parent)
    : QMainWindow(parent),
      engine_((std::filesystem::path(dataDirectory) / "documents.txt").string(), std::make_unique<TfidfRanker>()),
      history_((std::filesystem::path(dataDirectory) / "history.txt").string()) {
    engine_.initialize();
    setWindowTitle("SmartSearch 2026 | C++ Search Engine");
    setMinimumSize(900, 600);
    resize(1180, 760);
    setStyleSheet(kStyle);
    buildInterface();
    updateCount();
    changePage(kSearchPage);
}

void SearchWindow::buildInterface() {
    auto* root = new QWidget(this);
    root->setObjectName("root");
    setCentralWidget(root);
    auto* mainLayout = new QHBoxLayout(root);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);

    auto* sidebar = new QWidget(root);
    sidebar->setObjectName("sidebar");
    sidebar->setFixedWidth(230);
    auto* side = new QVBoxLayout(sidebar);
    side->setContentsMargins(18, 34, 18, 22);
    side->setSpacing(12);
    side->addWidget(plainLabel("✦ SmartSearch", "brand"));
    side->addWidget(plainLabel("C++ DOCUMENT ENGINE", "meta"));
    side->addSpacing(30);

    searchNav_ = new QPushButton("⌕   Search", sidebar);
    libraryNav_ = new QPushButton("▤   Document Library", sidebar);
    historyNav_ = new QPushButton("◷   Search History", sidebar);
    for (auto* nav : {searchNav_, libraryNav_, historyNav_}) {
        nav->setObjectName("nav");
        nav->setCursor(Qt::PointingHandCursor);
        side->addWidget(nav);
    }
    QObject::connect(searchNav_, &QPushButton::clicked, this, [this]() { changePage(kSearchPage); });
    QObject::connect(libraryNav_, &QPushButton::clicked, this, [this]() { changePage(kLibraryPage); });
    QObject::connect(historyNav_, &QPushButton::clicked, this, [this]() { changePage(kHistoryPage); });
    side->addStretch();
    documentCount_ = plainLabel("", "count", sidebar);
    side->addWidget(documentCount_);
    side->addWidget(plainLabel("LOCAL / OFFLINE • 2026", "meta", sidebar));
    mainLayout->addWidget(sidebar);

    pages_ = new QStackedWidget(root);
    pages_->addWidget(buildSearchPage());
    pages_->addWidget(buildLibraryPage());
    pages_->addWidget(buildHistoryPage());
    mainLayout->addWidget(pages_, 1);
}

QWidget* SearchWindow::buildSearchPage() {
    auto* page = new QWidget;
    auto* layout = new QVBoxLayout(page);
    layout->setContentsMargins(42, 44, 42, 28);
    layout->setSpacing(17);
    layout->addWidget(plainLabel("Find what matters.", "headline"));
    layout->addWidget(plainLabel("Search your documents with inverted indexing and TF-IDF-inspired ranking.", "caption"));

    auto* searchRow = new QHBoxLayout;
    searchRow->setSpacing(10);
    searchInput_ = new QLineEdit(page);
    searchInput_->setMinimumHeight(50);
    searchInput_->setPlaceholderText("Try: cpp interview, algorithms, machine learning...");
    searchInput_->setClearButtonEnabled(true);
    auto* button = new QPushButton("Search", page);
    button->setObjectName("primary");
    button->setMinimumHeight(50);
    button->setCursor(Qt::PointingHandCursor);
    searchRow->addWidget(searchInput_, 1);
    searchRow->addWidget(button);
    layout->addLayout(searchRow);
    QObject::connect(button, &QPushButton::clicked, this, [this]() { performSearch(); });
    QObject::connect(searchInput_, &QLineEdit::returnPressed, this, [this]() { performSearch(); });

    searchStatus_ = plainLabel("Search for a keyword to explore your collection.", "caption", page);
    layout->addWidget(searchStatus_);
    layout->addWidget(scrolledList(resultsLayout_, page), 1);
    resultsLayout_->addWidget(plainLabel("Start with a search — relevant documents will appear here.", "empty"));
    resultsLayout_->addStretch();
    return page;
}

QWidget* SearchWindow::buildLibraryPage() {
    auto* page = new QWidget;
    auto* layout = new QVBoxLayout(page);
    layout->setContentsMargins(42, 44, 42, 28);
    layout->setSpacing(16);
    auto* heading = new QHBoxLayout;
    auto* title = plainLabel("Document Library", "headline");
    auto* add = new QPushButton("+ Add Document");
    add->setObjectName("primary");
    add->setCursor(Qt::PointingHandCursor);
    heading->addWidget(title);
    heading->addStretch();
    heading->addWidget(add);
    layout->addLayout(heading);
    layout->addWidget(plainLabel("Add, review, and remove local documents. Index updates automatically.", "caption"));
    layout->addWidget(scrolledList(libraryLayout_, page), 1);
    QObject::connect(add, &QPushButton::clicked, this, [this]() { addDocument(); });
    return page;
}

QWidget* SearchWindow::buildHistoryPage() {
    auto* page = new QWidget;
    auto* layout = new QVBoxLayout(page);
    layout->setContentsMargins(42, 44, 42, 28);
    layout->setSpacing(16);
    layout->addWidget(plainLabel("Recent Searches", "headline"));
    layout->addWidget(plainLabel("The last 10 queries, saved locally. Click to search again.", "caption"));
    layout->addWidget(scrolledList(historyLayout_, page), 1);
    return page;
}

void SearchWindow::changePage(int index) {
    pages_->setCurrentIndex(index);
    searchNav_->setObjectName(index == kSearchPage ? "navActive" : "nav");
    libraryNav_->setObjectName(index == kLibraryPage ? "navActive" : "nav");
    historyNav_->setObjectName(index == kHistoryPage ? "navActive" : "nav");
    for (auto* nav : {searchNav_, libraryNav_, historyNav_}) {
        nav->style()->unpolish(nav);
        nav->style()->polish(nav);
        nav->update();
    }
    if (index == kLibraryPage) renderLibrary();
    if (index == kHistoryPage) renderHistory();
    if (index == kSearchPage) searchInput_->setFocus();
}

void SearchWindow::performSearch() {
    const QString text = searchInput_->text().trimmed();
    changePage(kSearchPage);
    if (text.isEmpty()) {
        searchStatus_->setText("Enter at least one keyword.");
        return;
    }
    try {
        const auto matches = engine_.search(text.toStdString());
        history_.record(text.toStdString());
        searchStatus_->setText(QString("%1 result(s) for \"%2\" • sorted by relevance")
                               .arg(matches.size()).arg(text));
        renderResults(matches);
    } catch (const std::exception& error) {
        QMessageBox::warning(this, "Search error", QString::fromUtf8(error.what()));
    }
}

void SearchWindow::renderResults(const std::vector<SearchResult>& results) {
    clearItems(resultsLayout_);
    if (results.empty()) {
        resultsLayout_->addWidget(plainLabel("No matching documents. Try a different keyword.", "empty"));
    }
    const std::size_t maximum = std::min<std::size_t>(results.size(), 20);
    for (std::size_t i = 0; i < maximum; ++i) {
        const auto& result = results[i];
        auto* card = panel();
        auto* cardLayout = new QVBoxLayout(card);
        cardLayout->setContentsMargins(20, 16, 20, 16);
        cardLayout->setSpacing(8);
        cardLayout->addWidget(plainLabel(qs(result.document.title), "cardTitle"));
        cardLayout->addWidget(plainLabel(
            QString("Rank #%1  •  Document ID: %2  •  %3  •  Score: %4")
                .arg(i + 1).arg(result.document.id).arg(result.document.year)
                .arg(result.score, 0, 'f', 2), "meta"));
        cardLayout->addWidget(plainLabel(excerpt(result.document.content), "caption"));
        resultsLayout_->addWidget(card);
    }
    resultsLayout_->addStretch();
}

void SearchWindow::renderLibrary() {
    clearItems(libraryLayout_);
    const auto& documents = engine_.listDocuments();
    if (documents.empty()) {
        libraryLayout_->addWidget(plainLabel("Your library is empty. Add the first document!", "empty"));
    }
    for (const auto& doc : documents) {
        auto* card = panel();
        auto* line = new QHBoxLayout(card);
        line->setContentsMargins(18, 15, 18, 15);
        line->setSpacing(14);
        auto* textBox = new QVBoxLayout();
        textBox->addWidget(plainLabel(qs(doc.title), "cardTitle"));
        textBox->addWidget(plainLabel(QString("ID %1  •  %2").arg(doc.id).arg(doc.year), "meta"));
        textBox->addWidget(plainLabel(excerpt(doc.content, 140), "caption"));
        line->addLayout(textBox, 1);
        auto* remove = new QPushButton("Delete", card);
        remove->setObjectName("danger");
        remove->setCursor(Qt::PointingHandCursor);
        line->addWidget(remove, 0, Qt::AlignTop);
        QObject::connect(remove, &QPushButton::clicked, this, [this, id = doc.id]() { removeDocument(id); });
        libraryLayout_->addWidget(card);
    }
    libraryLayout_->addStretch();
}

void SearchWindow::renderHistory() {
    clearItems(historyLayout_);
    const auto queries = history_.recent();
    if (queries.empty()) {
        historyLayout_->addWidget(plainLabel("No searches yet — make your first search!", "empty"));
    }
    for (const auto& query : queries) {
        auto* button = new QPushButton(QStringLiteral("⌕   ") + qs(query));
        button->setCursor(Qt::PointingHandCursor);
        QObject::connect(button, &QPushButton::clicked, this, [this, query]() {
            searchInput_->setText(qs(query));
            performSearch();
        });
        historyLayout_->addWidget(button);
    }
    historyLayout_->addStretch();
}

void SearchWindow::addDocument() {
    QDialog dialog(this);
    dialog.setWindowTitle("Add a Document");
    dialog.resize(520, 440);
    dialog.setStyleSheet(kStyle);
    auto* layout = new QVBoxLayout(&dialog);
    auto* form = new QFormLayout;
    auto* title = new QLineEdit(&dialog);
    auto* content = new QTextEdit(&dialog);
    auto* year = new QSpinBox(&dialog);
    title->setPlaceholderText("e.g. C++ Smart Pointers Guide");
    content->setPlaceholderText("Write the document content or a descriptive summary...");
    content->setMinimumHeight(170);
    year->setRange(1990, 2100);
    year->setValue(QDate::currentDate().year());
    form->addRow("Title", title);
    form->addRow("Content", content);
    form->addRow("Year", year);
    layout->addLayout(form);
    auto* actions = new QDialogButtonBox(QDialogButtonBox::Save | QDialogButtonBox::Cancel, &dialog);
    layout->addWidget(actions);
    QObject::connect(actions, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);
    QObject::connect(actions, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);

    while (dialog.exec() == QDialog::Accepted) {
        if (title->text().trimmed().isEmpty() || content->toPlainText().trimmed().isEmpty()) {
            QMessageBox::warning(this, "Missing fields", "Title and content are required.");
            continue;
        }
        try {
            engine_.addDocument(title->text().trimmed().toStdString(),
                                content->toPlainText().trimmed().toStdString(), year->value());
            updateCount();
            renderLibrary();
            QMessageBox::information(this, "Saved", "Document added and indexed successfully!");
        } catch (const std::exception& error) {
            QMessageBox::warning(this, "Save failed", QString::fromUtf8(error.what()));
        }
        break;
    }
}

void SearchWindow::removeDocument(int id) {
    if (QMessageBox::question(this, "Delete document", QString("Delete document ID %1?").arg(id),
                              QMessageBox::Yes | QMessageBox::No, QMessageBox::No) != QMessageBox::Yes) {
        return;
    }
    try {
        engine_.deleteDocument(id);
        updateCount();
        renderLibrary();
    } catch (const std::exception& error) {
        QMessageBox::warning(this, "Delete failed", QString::fromUtf8(error.what()));
    }
}

void SearchWindow::updateCount() {
    documentCount_->setText(QString("%1 documents indexed").arg(engine_.listDocuments().size()));
}
