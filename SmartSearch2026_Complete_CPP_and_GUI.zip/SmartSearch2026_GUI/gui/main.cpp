#include "mainwindow.hpp"

#include <QApplication>
#include <QCoreApplication>
#include <QDir>
#include <QMessageBox>
#include <QStandardPaths>

#include <exception>
#include <string>

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);
    QCoreApplication::setOrganizationName("SmartSearchDemo");
    QCoreApplication::setApplicationName("SmartSearch2026");

    const QString dataDirectory = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    if (dataDirectory.isEmpty() || !QDir().mkpath(dataDirectory)) {
        QMessageBox::critical(nullptr, "Storage error", "Could not create the application data directory.");
        return 1;
    }

    try {
        SearchWindow window(dataDirectory.toStdString());
        window.show();
        return app.exec();
    } catch (const std::exception& error) {
        QMessageBox::critical(nullptr, "SmartSearch startup error", QString::fromUtf8(error.what()));
        return 1;
    }
}
