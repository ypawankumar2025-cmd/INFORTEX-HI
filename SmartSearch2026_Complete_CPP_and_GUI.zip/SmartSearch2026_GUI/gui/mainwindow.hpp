#pragma once

#include "search_engine.hpp"

#include <QMainWindow>
#include <memory>
#include <string>

class QFrame;
class QLineEdit;
class QLabel;
class QPushButton;
class QStackedWidget;
class QVBoxLayout;

class SearchWindow final : public QMainWindow {
public:
    explicit SearchWindow(const std::string& dataDirectory, QWidget* parent = nullptr);

private:
    SearchEngine engine_;
    SearchHistory history_;

    QStackedWidget* pages_ = nullptr;
    QLineEdit* searchInput_ = nullptr;
    QLabel* searchStatus_ = nullptr;
    QLabel* documentCount_ = nullptr;
    QVBoxLayout* resultsLayout_ = nullptr;
    QVBoxLayout* libraryLayout_ = nullptr;
    QVBoxLayout* historyLayout_ = nullptr;
    QPushButton* searchNav_ = nullptr;
    QPushButton* libraryNav_ = nullptr;
    QPushButton* historyNav_ = nullptr;

    void buildInterface();
    QWidget* buildSearchPage();
    QWidget* buildLibraryPage();
    QWidget* buildHistoryPage();
    void changePage(int index);
    void performSearch();
    void renderResults(const std::vector<SearchResult>& results);
    void renderLibrary();
    void renderHistory();
    void addDocument();
    void removeDocument(int id);
    void updateCount();
};
