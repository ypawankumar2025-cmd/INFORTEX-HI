#include "search_engine.hpp"

#include <filesystem>
#include <iomanip>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>

namespace {

int readNumber(const std::string& prompt) {
    std::cout << prompt;
    std::string input;
    std::getline(std::cin, input);
    try {
        std::size_t parsed = 0;
        int number = std::stoi(input, &parsed);
        return parsed == input.size() ? number : -1;
    } catch (const std::exception&) {
        return -1;
    }
}

std::string readText(const std::string& prompt) {
    std::cout << prompt;
    std::string value;
    std::getline(std::cin, value);
    return value;
}

void printMenu() {
    std::cout << "\n========== SMARTSEARCH 2026 ==========\n"
              << "1. Search documents\n"
              << "2. Add document\n"
              << "3. List documents\n"
              << "4. Delete document\n"
              << "5. View recent searches\n"
              << "0. Exit\n";
}

}  // namespace

int main() {
    try {
        std::filesystem::create_directories("data");
        SearchEngine engine("data/documents.txt", std::make_unique<TfidfRanker>());
        SearchHistory history("data/history.txt");
        engine.initialize();
        std::cout << "Welcome! " << engine.listDocuments().size() << " documents indexed.\n";

        while (true) {
            printMenu();
            const int choice = readNumber("Enter your choice: ");

            if (choice == 0) {
                std::cout << "Goodbye!\n";
                break;
            }
            if (choice == 1) {
                const std::string query = readText("Search keywords: ");
                history.record(query);
                const auto results = engine.search(query);
                std::cout << "Found " << results.size() << " matching documents.\n";
                if (results.empty()) {
                    std::cout << "Try different or shorter keywords.\n";
                }
                for (std::size_t i = 0; i < results.size() && i < 10; ++i) {
                    const auto& result = results[i];
                    std::cout << "\n#" << i + 1 << " [ID " << result.document.id << "] "
                              << result.document.title << " (" << result.document.year << ")\n"
                              << "   Relevance: " << std::fixed << std::setprecision(2)
                              << result.score << "\n"
                              << "   " << result.document.content.substr(0, 100) << "\n";
                }
                if (results.size() > 10) {
                    std::cout << "Showing top 10 only.\n";
                }
            } else if (choice == 2) {
                const std::string title = readText("Document title: ");
                const std::string content = readText("Document description/content: ");
                const int year = readNumber("Publication year (1990-2100): ");
                if (title.empty() || content.empty() || year < 1990 || year > 2100) {
                    std::cout << "Invalid document: enter title, content and valid year.\n";
                } else {
                    const int id = engine.addDocument(title, content, year);
                    std::cout << "Saved and indexed successfully! ID = " << id << "\n";
                }
            } else if (choice == 3) {
                for (const auto& document : engine.listDocuments()) {
                    std::cout << "[" << document.id << "] " << document.title
                              << " (" << document.year << ")\n";
                }
            } else if (choice == 4) {
                const int id = readNumber("Document ID to delete: ");
                std::cout << (engine.deleteDocument(id) ? "Document deleted.\n" : "ID not found.\n");
            } else if (choice == 5) {
                const auto queries = history.recent();
                if (queries.empty()) {
                    std::cout << "No recent searches yet.\n";
                }
                for (const std::string& query : queries) {
                    std::cout << "- " << query << '\n';
                }
            } else {
                std::cout << "Unknown option, please choose 0-5.\n";
            }
        }
    } catch (const std::exception& ex) {
        std::cerr << "Error: " << ex.what() << '\n';
        return 1;
    }
    return 0;
}
