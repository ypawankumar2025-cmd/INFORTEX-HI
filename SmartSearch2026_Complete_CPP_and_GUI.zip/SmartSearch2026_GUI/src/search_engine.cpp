#include "search_engine.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <unordered_set>
#include <utility>

namespace {

// Tokenization turns "Modern C++ & DSA" into ["modern", "c", "dsa"].
std::vector<std::string> tokenize(const std::string& input) {
    std::vector<std::string> tokens;
    std::string current;

    for (unsigned char ch : input) {
        if (std::isalnum(ch)) {
            current.push_back(static_cast<char>(std::tolower(ch)));
        } else if (!current.empty()) {
            tokens.push_back(current);
            current.clear();
        }
    }
    if (!current.empty()) {
        tokens.push_back(current);
    }
    return tokens;
}

std::vector<Document> exampleDocuments() {
    return {
        {1, 2026, "C++ Object Oriented Programming",
         "Learn encapsulation inheritance abstraction polymorphism classes and objects using cpp"},
        {2, 2026, "Data Structures and Algorithms",
         "Practice arrays hash maps trees binary search sorting graphs and interview problems"},
        {3, 2025, "Modern C++ Fundamentals",
         "Understand functions loops vectors pointers references constructors and smart pointers in cpp"},
        {4, 2026, "Full Stack Development Roadmap",
         "Learn backend development frontend javascript databases http apis and git"},
        {5, 2025, "Machine Learning Basics",
         "Introduction to machine learning training datasets classification and model evaluation"},
        {6, 2026, "How Search Engines Work",
         "Search engine document indexing inverted index keyword retrieval ranking and relevance"},
        {7, 2024, "Database Management Essentials",
         "Learn sql relational databases indexing queries transactions and normalization"},
        {8, 2026, "Software Engineering Interview Preparation",
         "Prepare coding interviews cpp data structures system design and problem solving"}
    };
}

}  // namespace

DocumentRepository::DocumentRepository(std::string path) : filePath(std::move(path)) {}

bool DocumentRepository::exists() const {
    return std::filesystem::exists(filePath);
}

std::vector<Document> DocumentRepository::load() const {
    std::ifstream input(filePath);
    if (!input) {
        throw std::runtime_error("Cannot open document database: " + filePath);
    }

    std::vector<Document> loaded;
    std::string line;
    while (std::getline(input, line)) {
        std::istringstream parser(line);
        Document document;
        if (parser >> document.id >> document.year
                   >> std::quoted(document.title) >> std::quoted(document.content)) {
            loaded.push_back(std::move(document));
        }
    }
    return loaded;
}

void DocumentRepository::save(const std::vector<Document>& documents) const {
    std::ofstream output(filePath, std::ios::trunc);
    if (!output) {
        throw std::runtime_error("Cannot write document database: " + filePath);
    }
    for (const Document& document : documents) {
        output << document.id << '\t' << document.year << '\t'
               << std::quoted(document.title) << '\t'
               << std::quoted(document.content) << '\n';
    }
    if (!output) {
        throw std::runtime_error("Error while writing document database");
    }
}

double TfidfRanker::score(const Document& document,
                          const std::vector<std::string>& terms,
                          const InvertedIndex& index,
                          std::size_t totalDocuments) const {
    double relevance = 0.0;
    const auto titleTokens = tokenize(document.title);

    for (const std::string& term : terms) {
        const auto posting = index.find(term);
        if (posting == index.end()) {
            continue;
        }
        const auto frequency = posting->second.find(document.id);
        if (frequency == posting->second.end()) {
            continue;
        }

        const double tf = 1.0 + std::log(static_cast<double>(frequency->second));
        const double df = static_cast<double>(posting->second.size());
        const double idf = std::log(1.0 + (totalDocuments - df + 0.5) / (df + 0.5));
        const auto titleOccurrences = std::count(titleTokens.begin(), titleTokens.end(), term);
        relevance += tf * idf + 2.0 * static_cast<double>(titleOccurrences);
    }

    // A small, transparent demo recency boost (not Google's ranking formula).
    const int yearsSince2020 = std::clamp(document.year - 2020, 0, 6);
    return relevance * (1.0 + yearsSince2020 * 0.02);
}

SearchEngine::SearchEngine(std::string filePath,
                           std::unique_ptr<RankingStrategy> rankingAlgorithm)
    : repository(std::move(filePath)), ranker(std::move(rankingAlgorithm)) {
    if (!ranker) {
        throw std::invalid_argument("A ranking strategy is required");
    }
}

void SearchEngine::initialize() {
    if (repository.exists()) {
        documents = repository.load();
    } else {
        documents = exampleDocuments();
        repository.save(documents);
    }
    rebuildIndex();
}

void SearchEngine::rebuildIndex() {
    index.clear();
    for (const Document& document : documents) {
        for (const std::string& word : tokenize(document.title + " " + document.content)) {
            ++index[word][document.id];
        }
    }
}

int SearchEngine::addDocument(std::string title, std::string content, int year) {
    int nextId = 1;
    for (const Document& document : documents) {
        nextId = std::max(nextId, document.id + 1);
    }
    documents.push_back({nextId, year, std::move(title), std::move(content)});
    repository.save(documents);
    rebuildIndex();
    return nextId;
}

bool SearchEngine::deleteDocument(int id) {
    const auto oldSize = documents.size();
    documents.erase(std::remove_if(documents.begin(), documents.end(),
        [id](const Document& document) { return document.id == id; }), documents.end());
    if (documents.size() == oldSize) {
        return false;
    }
    repository.save(documents);
    rebuildIndex();
    return true;
}

std::vector<SearchResult> SearchEngine::search(const std::string& query) const {
    // Remove duplicate query words so repeated words do not inflate scores.
    const auto rawTerms = tokenize(query);
    std::unordered_set<std::string> unique(rawTerms.begin(), rawTerms.end());
    std::vector<std::string> terms(unique.begin(), unique.end());

    // Inverted index gives candidate IDs without searching every document's text.
    std::unordered_set<int> candidates;
    for (const std::string& term : terms) {
        const auto entry = index.find(term);
        if (entry != index.end()) {
            for (const auto& [documentId, count] : entry->second) {
                (void)count;
                candidates.insert(documentId);
            }
        }
    }

    std::vector<SearchResult> results;
    for (const Document& document : documents) {
        if (candidates.count(document.id)) {
            results.push_back({document, ranker->score(document, terms, index, documents.size())});
        }
    }
    std::sort(results.begin(), results.end(), [](const SearchResult& a, const SearchResult& b) {
        if (a.score != b.score) {
            return a.score > b.score;
        }
        return a.document.id < b.document.id;
    });
    return results;
}

const std::vector<Document>& SearchEngine::listDocuments() const {
    return documents;
}

SearchHistory::SearchHistory(std::string path) : filePath(std::move(path)) {}

void SearchHistory::record(const std::string& query) const {
    if (tokenize(query).empty()) {
        return;
    }
    std::ofstream output(filePath, std::ios::app);
    if (!output) {
        throw std::runtime_error("Cannot open search history");
    }
    output << query << '\n';
}

std::vector<std::string> SearchHistory::recent(std::size_t maximum) const {
    std::ifstream input(filePath);
    std::vector<std::string> queries;
    std::string line;
    while (std::getline(input, line)) {
        if (!line.empty()) {
            queries.push_back(line);
        }
    }
    if (queries.size() > maximum) {
        queries.erase(queries.begin(), queries.end() - static_cast<std::ptrdiff_t>(maximum));
    }
    std::reverse(queries.begin(), queries.end());
    return queries;
}
