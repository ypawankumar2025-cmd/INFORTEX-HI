#pragma once

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

struct Document {
    int id{};
    int year{};
    std::string title;
    std::string content;
};

struct SearchResult {
    Document document;
    double score{};
};

// word -> { document ID -> number of times the word appears }
using InvertedIndex = std::unordered_map<std::string, std::unordered_map<int, int>>;

class DocumentRepository {
private:
    std::string filePath;

public:
    explicit DocumentRepository(std::string path);
    std::vector<Document> load() const;
    void save(const std::vector<Document>& documents) const;
    bool exists() const;
};

// Abstraction: a ranking algorithm must implement the score() contract.
class RankingStrategy {
public:
    virtual ~RankingStrategy() = default;
    virtual double score(const Document& document,
                         const std::vector<std::string>& terms,
                         const InvertedIndex& index,
                         std::size_t totalDocuments) const = 0;
};

// Inheritance + runtime polymorphism: swap in a different ranker later.
class TfidfRanker final : public RankingStrategy {
public:
    double score(const Document& document,
                 const std::vector<std::string>& terms,
                 const InvertedIndex& index,
                 std::size_t totalDocuments) const override;
};

class SearchEngine {
private:
    DocumentRepository repository;
    std::unique_ptr<RankingStrategy> ranker;
    std::vector<Document> documents;
    InvertedIndex index;

    void rebuildIndex();

public:
    SearchEngine(std::string filePath, std::unique_ptr<RankingStrategy> rankingAlgorithm);
    void initialize();
    int addDocument(std::string title, std::string content, int year);
    bool deleteDocument(int id);
    std::vector<SearchResult> search(const std::string& query) const;
    const std::vector<Document>& listDocuments() const;
};

class SearchHistory {
private:
    std::string filePath;

public:
    explicit SearchHistory(std::string path);
    void record(const std::string& query) const;
    std::vector<std::string> recent(std::size_t maximum = 10) const;
};
